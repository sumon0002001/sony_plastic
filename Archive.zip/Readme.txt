This is the site for the industry in Bangladesh named Sony Plastic Complex.
